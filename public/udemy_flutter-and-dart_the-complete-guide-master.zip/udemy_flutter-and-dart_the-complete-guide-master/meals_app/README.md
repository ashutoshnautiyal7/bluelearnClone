# Meals App

## Screenshots

| <img src="https://i.imgur.com/96YYKXL.png"> | <img src="https://i.imgur.com/kyCCb0G.png"> | <img src="https://i.imgur.com/nd03xrP.png"> |
| ------------ | ------------ | ------------ |
| <img src="https://i.imgur.com/kx52FZt.png"> | <img src="https://i.imgur.com/7fAQV0p.png"> |  <img src="https://i.imgur.com/Jse2wo6.png"> |