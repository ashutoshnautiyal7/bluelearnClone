# Chat app

##Screenshots

|                   1.                    |                    2.                   |
| :--------------------------------------:| :-------------------------------------: |
|  <img src="https://i.imgur.com/pFrnlol.jpg">  |  <img src="https://i.imgur.com/PymynEe.jpg">  |
|                   3.                    |                    4.                   |
|  <img src="https://i.imgur.com/cGE8QKd.jpg">  |  <img src="https://i.imgur.com/eLQuhUx.jpg">  |